# Main Functionality Test Configs

## purpose
Test main features and config options of cloud-init such as logging, output
redirection, early init and integration with init system

## structure
Should have one or more test configs for all main cloud-init output and logging
options, and basic functionality test cases

# vi: ts=4 expandtab
